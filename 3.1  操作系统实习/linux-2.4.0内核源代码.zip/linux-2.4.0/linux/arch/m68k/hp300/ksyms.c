/*
 *  linux/arch/m68k/hp300/ksyms.c
 *
 *  Copyright (C) 1998 Philip Blundell <philb@gnu.org>
 *
 *  This file contains the HP300-specific kernel symbols.  None yet. :-)
 */

#include <linux/module.h>
