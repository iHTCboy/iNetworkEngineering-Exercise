import java.sql.*;  //JDBC使用
import java.util.*;

public class AccessDBOperation
{ 
    private Connection conn;  //用于与数据库连接的Connection对象
    private Statement stmt;  //用于执行SQL语句的Statement对象
   
    public AccessDBOperation()
    {
        init();

    }

    //初始化操作Access数据库的相关工作：加载驱动，创建连接，创建Statement对象
    public void init()
    {
        try
        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");  //加载JDBC－ODBC驱动
            String url = "jdbc:odbc:Driver={MicroSoft Access Driver (*.mdb, *.accdb)};DBQ=F:\\课件（叶恒舟）\\程序\\QQChats\\ClientInfo.accdb";  //连接Access数据库的URL，数据库文件存放于当前文件夹下的database中
            Connection conn =  DriverManager.getConnection(url);  //不需要用户名与密码
            stmt = conn.createStatement();  //创建Statement对象，用于执行SQL语句.            
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("无法加载JDBC－ODBC驱动程序");
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
    }
    
    public int redit(String[] data)
    {
        if (stmt == null || data.length != 3)
            return -1;
                
        try
        {
            int times = 0;
            while(times < 10)
            {
                int id = (int)(Math.random() * 55535 + 10000);
                //int id = 3556;
                String sql = "Select * from userInfo where id = " + id;
                ResultSet rst = stmt.executeQuery(sql);  //执行查询表的操作，返回结果存放于rst中
            
                if (rst.next() == true)
                {
                    times ++;
                    rst.close();  //关闭记录集
                }
                else
                {
                    sql = "insert into userInfo (id,username,password,sex) values (" + id + ",'" + data[0] + "','" + data[1] + "','" + data[2] + "')";
                    //System.out.println(sql);
                    stmt.executeUpdate(sql);
                    return id;
                }
            }
            
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
        
        return -1;        
    }
    
    //关闭数据库。操作之前，请确认与之相关联的ResultSet对象已经被关闭
    public void close()
    {
        try
        {
            if (stmt != null)  //先关闭Statement对象，再关闭Connection对象
                stmt.close();
            if (conn != null)
                conn.close();                
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }        
    }
    
}
