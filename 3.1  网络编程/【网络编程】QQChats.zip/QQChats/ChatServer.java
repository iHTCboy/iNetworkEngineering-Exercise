import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ChatServer implements RuleConstants
{
    public ChatServer()
    {
        //main();
    }

    public void main()
    {
        try
        {                       
            ServerSocket serverSocket = new ServerSocket(PORT);  //创建服务器套接字
            System.out.println("等待连接...");
            
            while(true)
            {
                Socket toClient = serverSocket.accept();  //侦听来自客户端的连接请求; 程序将在此之后阻塞，直到有客户连接上来           
                System.out.println("连接请求来自：" + toClient.getInetAddress());  //显示连接的客户信息
                DataInputStream in = new DataInputStream(toClient.getInputStream()); //接收数据流，定义为final，便于在内部类中使用
                DataOutputStream out = new DataOutputStream(toClient.getOutputStream()); //发送数据流
                
                String info = in.readUTF();
                switch(analysis(info))
                {
                    case REGISTER:
                        doRegit(info, out);
                        break;
                }
            }         
        }
        catch(Exception e)   //在网络通信过程中可能会产生很多异常，这里简单化了异常处理，在真正的应用软件中是不合适的。
        {
            e.printStackTrace();
        }
    }
    
    private int analysis(String info)
    {
        int index = info.indexOf(' ');
        String seq = info.substring(0, index);
        return Integer.parseInt(seq);
    }
    
    public void doRegit(String info, DataOutputStream out)
    {
        int index = info.indexOf(' ');
        info = info.substring(index + 1);
        String[] data = info.split("#");
        
        AccessDBOperation db = new AccessDBOperation();
        int id = db.redit(data);
        db.close();
        
        sendRegitInfo(id, out);
        
        
    }
    
    public void sendRegitInfo(int id, DataOutputStream out)
    { 
        String info = "";
        if (id == -1)
        {
            //发送注册失败信息
            info = "" + REGFAIL + " ";
        }
        else
        {
            //
            info = "" + REGSUCESS + " " + id;
        }
        
        try
        {
            out.writeUTF(info);
            out.flush();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
