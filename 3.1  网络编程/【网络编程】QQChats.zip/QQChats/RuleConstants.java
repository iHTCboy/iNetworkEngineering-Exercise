public interface RuleConstants
{
    String IPADDRESS = "LocalHost";
    int PORT = 5678;  //服务器端口号
    int LOGIN = 1;  //用户登录时发送的消息
    int LOGINSUCESS = 2;  //服务发送的登录成功的消息
    int LOGINFAIL = 3;  //服务发送的登录失败的消息
    int QUIT = 4;  //用户退出时发送的消息
    int REGISTER = 5;  //用户注册时发送的消息
    int REGSUCESS = 6; //服务发送的注册成功的消息
    int REGFAIL = 7; //服务发送的注册失败的消息
    int FIND = 8;  //用于查寻用户时发送的消息
    int FRIENDAPPLY = 9; //用于申请加好友的消息
    /*
用于同意加好友的消息：FRIENDAGREE
用于拒绝加好友的消息：FRIENDREFUSE
用户给好友发送消息：SENDMSG
*/
}
