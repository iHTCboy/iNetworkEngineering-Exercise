import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class RegisterFrame extends JFrame implements ActionListener, RuleConstants
{
    private JTextField userName = new JTextField(10);
    private JPasswordField password = new JPasswordField(10);
    private String[] data = {"男", "女"};
    private JComboBox sex = new JComboBox(data);
    private JButton regitBtn = new JButton("注册");
    private JButton resetBtn = new JButton("重置");
    private JButton quitBtn = new JButton("退出");

    public RegisterFrame()
    {
        setTitle("Register Window");
        makeFrame();
        pack();
        setVisible(true);
    }
    
    private void makeFrame()
    {
        Container con = getContentPane();
        con.setLayout(new BorderLayout());
        JPanel centerPanel = new JPanel(new GridLayout(3, 2));
        JPanel bottomPanel = new JPanel(new FlowLayout());
        con.add(centerPanel, BorderLayout.CENTER);
        con.add(bottomPanel, BorderLayout.SOUTH);
        
        centerPanel.add(new JLabel("Name"));
        centerPanel.add(userName);
        centerPanel.add(new JLabel("Password"));
        centerPanel.add(password);
        centerPanel.add(new JLabel("Sex"));
        centerPanel.add(sex); 
        sex.setEditable(false);
        
        bottomPanel.add(regitBtn);
        bottomPanel.add(resetBtn);
        bottomPanel.add(quitBtn);
        
        regitBtn.addActionListener(this);
        resetBtn.addActionListener(this);
        quitBtn.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == regitBtn) //
        {
            try
            {
                Socket client = new Socket(IPADDRESS,PORT);
                DataInputStream in = new DataInputStream(client.getInputStream()); 
                DataOutputStream out = new DataOutputStream(client.getOutputStream());
                String info = createSendInfo();
                out.writeUTF(info);
                info = in.readUTF();
                analysis(info);
            }
            catch(Exception e1)
            {
            }
        }
        if (e.getSource() == resetBtn) //
        {
            userName.setText("");
            password.setText("");
            sex.setSelectedIndex(0);
        }
        if (e.getSource() == quitBtn) //
        {
            System.exit(0);
            //setVisible(false);
        }        
    }
    
    private String createSendInfo()
    {
        String nameStr = userName.getText().trim();
        String pwStr = new String(password.getPassword());
        String sexStr = (String) (sex.getSelectedItem()); 
        
        String info = "" + REGISTER + " ";
        info = info + nameStr + "#" + pwStr + "#" + sexStr;
        return info;        
    }
    
    public void analysis(String info)
    {
        int index = info.indexOf(' ');
        String seq = info.substring(0, index);
        int value = Integer.parseInt(seq);
        if (value == REGSUCESS)
        {
            System.out.println("regedit success and you get an id " + info.substring(index + 1));
        }
        else if (value == REGFAIL)
        {
            System.out.println("regedit failed!");
        }
    }
}
