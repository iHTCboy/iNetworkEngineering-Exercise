package business;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import Form.*;
public class ChatBase extends JFrame implements ActionListener{

	/**
	 * ���촰�ڻ���
	 * ��Ϣ���촰�ڵĹ���Ͳ���
	 */
	protected int userNum;
	protected int friendNum;
	protected String friendIp;
	protected String userName;
	
	protected boolean openRecrod = false;
	protected JLabel infomation;
	protected JTextArea input;
	protected JTextArea output;
	protected JPanel pnlButtom;
	protected JPanel pnlCenter;
	protected JButton btnSend;
	protected JButton btnCancel;
	protected JButton btnRecord;
	protected Client parent;
	protected JScrollPane panel;
	protected JTextArea recrod;
	
	//���ڳ�ʼ�ؼ��Ͳ���,����Ϊ���촰�ڵĲ���
	public void setup()
	{
		infomation = new JLabel("");
		String info = User.getInfo(friendNum);
		infomation.setText(info);
		input = new JTextArea();
		output = new JTextArea();
		JScrollPane jspInput = new JScrollPane(input,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JScrollPane jspOutput = new JScrollPane(output,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		pnlButtom = new JPanel();
		pnlCenter = new JPanel();
		pnlButtom.setLayout(new FlowLayout());
		btnSend = new JButton("����");
		btnCancel = new JButton("ȡ��");
		btnRecord = new JButton("�����¼");
		btnSend.addActionListener(this);
		btnCancel.addActionListener(this);
		btnRecord.addActionListener(this);
		pnlCenter.setLayout(new BorderLayout());
		pnlCenter.add("Center",jspInput);
		pnlCenter.add("South",jspOutput);
		javax.swing.JSplitPane js = new JSplitPane(JSplitPane.VERTICAL_SPLIT,jspInput,jspOutput);
		js.setDividerSize(4);
		jspInput.setPreferredSize(new Dimension(200,200));
		
		pnlButtom.add(btnSend);
		pnlButtom.add(btnCancel);
		pnlButtom.add(btnRecord);
		
		recrod = new JTextArea();
		recrod.setPreferredSize(new Dimension(200,280));
		panel = new JScrollPane(recrod,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.getContentPane().add(panel,"East");
		
		getContentPane().add("North",infomation);
		getContentPane().add("Center",pnlCenter);
		getContentPane().add("South",pnlButtom);
		getContentPane().add(js);
		input.setEditable(false);
		
	}

	
	public ChatBase() 
	{
		
	}
	
	public void setMessage(String string) {
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɷ������
	}
}
