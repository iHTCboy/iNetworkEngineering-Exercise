package Form;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JPanel;
import DataLayer.SqlHelper;
public class Server extends Frame implements ActionListener{
	
	private boolean serving = false;
	private Color bg = new Color(241,250,255);
	private String rightNow;	
	private InetAddress svrAddress;
	private ServerSocket server;
	private ServerThread st;
	private Hashtable ht;		// ��¼ String userName -> DataOutPutStream out
	private Hashtable ht_s;		// ��¼ String userName -> Socket connection
	private SqlHelper sh = new SqlHelper();
	private Label svrIP = new Label("Server IP:");
	private TextField showSvrIP = new TextField();
	private Label svrPort = new Label("Server port:");
	private TextField getSvrPort = new TextField("3000");
	private Button enter = new Button("Start");
	private TextArea output = new TextArea();
	private TextArea send = new TextArea();
	private Label user = new Label("User (0)");
	private List list = new List();
	private JButton sendMessage = new JButton();
	 
	// ��Ӧ�رհ�ť���ڲ���
	private class WindowCloser extends WindowAdapter
	{
		public void windowClosing(WindowEvent we)
		{
			System.exit(0);
		}
	}
	
	// �������÷������ڹ��췽���������
	private void setup()
	{		
		Panel top = new Panel();
		top.setLayout(new FlowLayout());
		top.add(svrIP);
		svrIP.setBackground(bg);
		top.add(showSvrIP);
		showSvrIP.setBackground(bg);
		top.add(svrPort);
		svrPort.setBackground(bg);
		top.add(getSvrPort);
		getSvrPort.setBackground(bg);
		top.add(enter);
		enter.setBackground(bg);
		
		Panel east = new Panel();
		east.setLayout(new BorderLayout());
		east.add("North", user);
		user.setBackground(bg);
		east.add("Center", list);
		list.setBackground(bg);
		
		setLayout(new BorderLayout());
		add("North", top);
		top.setBackground(bg);
		add("East", east);
		east.setBackground(bg);
		add("Center", output);
		output.setBackground(bg);		
		JPanel pBottom = new JPanel();
		pBottom.setLayout(new BorderLayout());
		pBottom.add("Center",send);
		pBottom.add("South",sendMessage);
		send.setBackground(bg);
		send.setPreferredSize(new Dimension(500,100));
		sendMessage.setText("����ϵͳ��Ϣ");
		sendMessage.setPreferredSize(new Dimension(100,20));
		add("South",pBottom);
		setBackground(bg);
		register();
	}
	
	//Ϊ����ϵͳ��Ϣע���¼�
	private void register()
	{
		sendMessage.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
			Enumeration en = ht.elements();
			while(en.hasMoreElements())
			{
				DataOutputStream out = (DataOutputStream)(en.nextElement());
				try {
					out.writeUTF("S"+"ϵͳ��Ϣ "+send.getText());
				} catch (IOException e1) {
					// TODO �Զ����� catch ��
					e1.printStackTrace();
				}
			}
			send.setText("");
		}
		});
	}
	
	// ���췽��
	public Server()throws UnknownHostException, IOException
	{
		super("JIM������������");
		serving = false;
		svrAddress = InetAddress.getLocalHost();
		byte[] ip = svrAddress.getAddress();
		showSvrIP.setText((ip[0]&0xFF)+"."+(ip[1]&0xFF)+"."
				+(ip[2]&0xFF)+"."+(ip[3]&0xFF));

		showSvrIP.setEditable(false);
		output.setEditable(false);
		
		enter.addActionListener(this);
		addWindowListener(new WindowCloser());
		sh.setStatement(sh.getConnection());
		setup();
		pack();
		setSize(500, 400);
		show();
	}
	
	
	// ���ڽ��տͻ���Ϣ���߳���
	private class ServerThreadSingle extends Thread{
		public Socket connection;
		private DataInputStream in;
		private DataOutputStream out;
		private boolean login;
		private String userName;
		public ServerThreadSingle(Socket _connection){
			try{
				connection = _connection;
				in = new DataInputStream(connection.getInputStream());
				out = new DataOutputStream(connection.getOutputStream());
				login = false;
				userName = new String("");
				start();				
			}catch(IOException ioe){
				output.append("Error: "+ioe);
			}			
		}
		
		private void sendForOne(String line,String top)
		{
			String recName = line.substring(1,line.indexOf(" "));
			//System.out.println(recName);
			rightNow = Calendar.getInstance().getTime().toString();
			output.append(rightNow+"\n"+userName+line+"\n\n");
			//��ָ�����û�������Ϣ
			DataOutputStream out = null;
			try
			{
				out = (DataOutputStream)ht.get(recName);
			}
			catch(Exception e)
			{
				
			}
			if(out!=null)
			{
				//System.out.println(line);
				try {
					out.writeUTF(top+userName+" "+line.substring(line.indexOf(" ")));
				} catch (IOException e) {
					// TODO �Զ����� catch ��
					e.printStackTrace();
				}
			}
		}
		
		private void sendForAllFriend(String userNum)
		{
			//��ǰ�û��ĺ��ѷ�����Ϣ ���ߺ����Լ�Ҫ�˳�
			if(userNum.charAt(0)=='Q')
			{
				userNum = userNum.substring(1);
				ResultSet rs = sh.getQuery("select friendNum from tbl_Friends where userNum="+ userNum);
				///System.out.println(userNum);
				try {
					while(rs.next())
					{
						String friendNum = rs.getString(1);
						DataOutputStream out = null;
						try
						{
							out = (DataOutputStream)ht.get(friendNum);
						}
						catch(Exception e)
						{
							
						}
						if(out!=null)
						{
							//System.out.println(friendNum);
							out.writeUTF("Q"+userNum);
						}
						
					}
				} catch (SQLException e) {
					// TODO �Զ����� catch ��
					e.printStackTrace();
				} catch (IOException e) {
					// TODO �Զ����� catch ��
					e.printStackTrace();
				}
			}
		}
		
		
		
		public void run(){
			try{
				String line = new String("Q");
				while(!login){
					if(!serving) break;
					line = in.readUTF();
					if(line.charAt(0) == 'L'){						
						userName = line.substring(2);
						// ���½���û����͵�ǰ�����û��б�
						login = true;
						list.add(userName);
						user.setText("User ("+list.getItemCount()+")");
						String[] str = list.getItems();
						line = "A ";				//accepted
						for (int i = 0; i < str.length; i ++){
							line += (str [i] + " ");
						}
						out.writeUTF(line);
						line = "L "+userName;
						rightNow = Calendar.getInstance().getTime().toString();
						output.append(rightNow+"\n"+userName+" log in.\n\n");
						// �������û�����������ǰ�ͻ���������Ϣ
						for(Enumeration e = ht.elements(); e.hasMoreElements();){
							DataOutputStream out = (DataOutputStream)(e.nextElement());
							out.writeUTF(line);
						}
						ht.put(userName, out);	// ����¼�Ŀͻ���������
						ht_s.put(userName, connection);
					}
				}
				while(login){
					String recName = null; //��ϢҪ���͸����û�
					line = in.readUTF();
					if(!serving) break;
					if(line.charAt(0) == 'Q'){
						out.writeUTF("Q");
						login = false;
						ht.remove(userName);	// ���˳���¼�Ŀͻ����������޳�
						ht_s.remove(userName);
						list.remove(userName);
						user.setText("User ("+list.getItemCount()+")");
						line = "Q "+userName;
						rightNow = Calendar.getInstance().getTime().toString();
						output.append(rightNow+"\n"+userName+" log out.\n\n");
						sendForAllFriend(line);
					}
					else{//���ܵ���ͨ��Ϣ
						//��ָ���û�������Ϣ
						sendForOne(line,"M");
					}
				}
				in.close();
				out.close();
				connection.close();
			}catch(SocketException se){
				ht.remove(userName);
				ht_s.remove(connection);
				list.remove(userName);
				output.append("Connection to "+userName+" closed\n");
			}catch(IOException ioe){
				if(!(ioe instanceof EOFException)){
					output.append("Error: "+ioe+"\n\n");
				}				
			}
		}		
	}
	
	
	// ���ڽ��ܿͻ�����������߳���
	private class ServerThread extends Thread{
		private boolean running;
		public ServerThread()
		{
			start();
		}
		public void run()
		{
			try{
				while(serving){
					Socket connection = server.accept();
					ServerThreadSingle handler
						= new ServerThreadSingle(connection);
				}
			}catch(SocketException se){
				rightNow = Calendar.getInstance().getTime().toString();
				output.append(rightNow+"\nServing stoped.\n\n");
			}catch(IOException ioe){
				output.append("Error: "+ioe+"\n\n");
			}		
		}
	}
	// ��Ϣ��������
	public void actionPerformed(ActionEvent event)
	{
		if(event.getSource() == enter) 
		{
			if(serving){				
				try{
					for(Enumeration e = ht.elements(); e.hasMoreElements();){
						DataOutputStream out = (DataOutputStream)(e.nextElement());
						out.writeUTF("Q");					
					}
					serving = false;
					ht.clear();
					ht_s.clear();
					list.clear();
					user.setText("User (0)");
					server.close();
					enter.setLabel("Start");				
				}catch(SocketException se){
					rightNow = Calendar.getInstance().getTime().toString();
					output.append(rightNow+"\nServing stoped.\n\n");
				}catch(IOException ioe){
					output.append("Error: "+ioe+"\n\n");
				}
			}
			else{				
				try{
					server = new ServerSocket(Integer.parseInt(getSvrPort.getText()));
					rightNow = Calendar.getInstance().getTime().toString();
					output.append(rightNow+"\nServing started.\n\n");
					enter.setLabel("Stop");
					ht = new Hashtable();
					ht_s = new Hashtable();
					st = new ServerThread();
					serving = true;
				}catch(IOException ioe){
					output.append("Error: "+ioe+"\n\n");
				}				
			}
		}
	}
	
	// ������
	public static void main(String args [])throws UnknownHostException, IOException
	{
		Server s = new Server();
	}

}
