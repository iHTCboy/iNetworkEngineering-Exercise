package Form;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.FocusManager;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import DataLayer.SqlHelper;
//��½���棬�����ڼ�˵˵����ı�д���̡����ȹ���һ���࣬��setup()������ʼ�����塣
//����ҳ��Ĳ�����setup()��������ɣ�Ȼ��԰�ť����ע��register()��������
public class Login extends JFrame {

	private JPasswordField passwordField;
	private JComboBox cboxuserName;
	private JButton button;
	private static int errorCount=0;
	SqlHelper sh ;
	JPanel panel;
	public static void main(String args[]) {
		try {
			Login frame = new Login();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	public void setup()
	{
	    panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(5, 55, 310, 125);
		getContentPane().add(panel);
		panel.setBackground(new Color(241,250,255));
		 final JLabel lbluserName = new JLabel("JIM�ʻ�");
		 lbluserName.setBounds(30, 40, 50, 15);
		 final JLabel lblpassword = new JLabel("JIM����");
		 lblpassword.setBounds(30, 90, 50, 15);
		 final JLabel lblregister = new JLabel("�����ʻ�");
		 
		 //�����ʻ�������¼�
		 lblregister.addMouseListener(new MouseAdapter() {
		 	public void mouseEntered(MouseEvent e) {
		 		
		 		lblregister.setForeground(Color.RED);
		 	}
		 	public void mouseExited(MouseEvent e) {
		 		lblregister.setForeground(Color.BLUE);
		 	}
		 	public void mouseClicked(MouseEvent e) {
		 		Register frame = new Register();
				frame.setVisible(true);
		 	}
		 });
		 
		 lblregister.setForeground(new Color(0, 0, 255));
		 lblregister.setBounds(230, 40, 70, 15);
		 final JLabel lblrevert = new JLabel("��������?");
		 lblrevert.setForeground(new Color(0, 0, 255));
		 lblrevert.setBounds(230, 90, 70, 15);
		 panel.add(lbluserName);
		 panel.add(lblpassword);
		 panel.add(lblregister);
		 panel.add(lblrevert);
		 
		cboxuserName = new JComboBox();
		cboxuserName.setBounds(90, 38, 120, 20);
		cboxuserName.setEditable(true);
		panel.add(cboxuserName);
		

	    passwordField = new JPasswordField();
	    passwordField.setBounds(90, 88, 120, 21);
	    panel.add(passwordField);
	    cboxuserName.addItem("���������");
	}

	
	
	
	public void register()
	{
		//�˺������س��������¼�
		cboxuserName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FocusManager.getCurrentManager().focusNextComponent();
			}
		});
		
		//�����س��������¼�
	    passwordField.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		button.doClick();
	    	}
	    });
	    
		//��¼��ť�������¼�
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName =((String) cboxuserName.getSelectedItem());
				String password = new String(passwordField.getPassword());
				if(userName==null||password==null||userName.equals("")||password.equals(""))
				{
					JOptionPane.showMessageDialog(Login.this, "�벹��������Ϣ!");
					return;
				}
				userName = userName.trim().replace("'", "");
				password = password.trim().replace("'", "");
				int userNum = 0;
				try
				{
					userNum = new Integer(userName).intValue();
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(Login.this, "�û�������ȷ");
					return;
				}
				sh = new SqlHelper();
				sh.setStatement(sh.getConnection());
				ResultSet rs = sh.getQuery("select userName,isOnLine from tbl_Users where userNum="+userNum+" and password='"+ password +"'");
				try {
					if(rs.next())
					{
						if(rs.getInt(2)!=1)
						{
							sh.closeStatement();
							Client c = new Client(userNum);
							c.setVisible(true);
							Login.this.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(Login.this, "���û��Ѿ���¼");
							return;
						}
					}
				} catch (SQLException e1) {
					// TODO �Զ����� catch ��
					e1.printStackTrace();
				}
			}
		});
	}
	public Login() {
		super("JIM��¼����");
		getContentPane().setLayout(null);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = 330;
		int height = 250;
		this.setBounds((d.width - width) / 2, (d.height - height) / 2, width, height);
		this.setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon logo = new ImageIcon(this.getClass().getResource("/image/top.jpg"));
		final JLabel login = new JLabel(logo);
		login.setBounds(0, 0, 330, 55);
		getContentPane().add(login);
		getContentPane().setBackground(new Color(225,245,252));
		setup();
		
		/**
		 * *��¼��ť�������¼�
		 */
	    button = new JButton();
		button.setText("��¼");
		button.setBounds(220, 190, 80, 23);
		
		register();
		getContentPane().add(button);
	
		//
	}

}
