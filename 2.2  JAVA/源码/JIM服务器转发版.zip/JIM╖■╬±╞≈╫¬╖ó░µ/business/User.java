package business;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;

import DataLayer.SqlHelper;

//�û����࣬�Ƕ��û��Ĳ���
public class User implements Comparator {
	public int userNum;
	public String userName;
	public String password;
	public int isOnLine;
	public String ip;
	public String userInformation;
	public int userLogo;
	public String sex;
	public String email;
	private static SqlHelper sh;
	public User()
	{
		
	}
	public User(int num,String name,String password,int online,String ip,String info,int logo,String sex,String email)//User�Ĺ��캯��
	{
		userNum = num;
		userName= name;
		this.password = password;
		this.isOnLine = online;
		this.ip = ip;
		this.userInformation = info ;
		this.userLogo = logo;
		this.sex = sex ;
		this.email = email;
	}
	
	public void updateUser()  //�����û�
	{
		  sh = new SqlHelper();
		  sh.setStatement(sh.getConnection());
		  sh.getUpdate("update tbl_Users set userName='"+userName+"',sex='"+sex+"',userInformation='"+userInformation+"',email='"+email+"',userLogo="+userLogo+" where userNum='"+userNum+"'");
	}
	public static User getUser(String que)//��ȡ�����û���Ϣ
	{
		  sh = new SqlHelper();
		  sh.setStatement(sh.getConnection());
		  ResultSet rs = sh.getQuery(que);
		  User temp = null;
		  try {
			if(rs.next())
			{
				temp = new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6),rs.getInt(7),rs.getString(8),rs.getString(9));
			}
		} catch (SQLException e) {
			// TODO �Զ����� catch ��
			e.printStackTrace();
		}
		return temp;
	}
	public int compare(Object arg0, Object arg1) {    //�Ƚ��û�����ֵ����Ҫ�Ժ������������
		// TODO �Զ����ɷ������
		User u1 = (User)arg0;
		User u2 = (User)arg1;
		return u2.isOnLine - u1.isOnLine;
	}
	public boolean equals(Object obj)     //��ȡ�Ƿ�����
	{
		User u = (User)obj;
		return this.isOnLine == u.isOnLine;
	}
	public static void setOnLine(int online,int user)   //��������
	{
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		sh.getUpdate("update tbl_Users set isOnLine ="+online + " where userNum="+user);
	}
	public static void setIP(String ip,int user)     //�����ݿ���д������IP�������һ�ε�½IP
	{
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		sh.getUpdate("update tbl_Users set IP ='"+ ip + "' where userNum="+user);
	}
	public static String getName(int userNum)       //ȡ���û���
	{
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		ResultSet rs = sh.getQuery("select userName from tbl_Users where userNum="+userNum);
		String userName = null;
		try {
			if(rs.next())
			{
				userName = rs.getString(1);
			}
		} catch (SQLException e) {
		}
		return userName;
	}
	public static int getIsOnLine(int userNum)   //ȡ���Ƿ�����
	{
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		ResultSet rs = sh.getQuery("select isOnLine from tbl_Users where userNum="+userNum);
		int online = -1;
		try {
			if(rs.next())
			{
				online = rs.getInt(1);
			}
		} catch (SQLException e) {
		}
		return online;
	}
	public static String getInfo(int userNum)    //ȡ���û���ע��Ϣ����Ϣ
	{
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		ResultSet rs = sh.getQuery("select userInformation from tbl_Users where userNum="+userNum);
		String userInformation = null;
		try {
			if(rs.next())
			{
				userInformation = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO �Զ����� catch ��
			e.printStackTrace();
		}
		return userInformation;
	}
}
