package Form;
import java.awt.*;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingConstants;

import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;

import DataLayer.*;
import business.*;

public class Client extends JFrame{

	private SqlHelper sh;
	private int userNum;
	private int friendNum;
	private Vector friend;  //�洢������Ϣ�б�
	private Vector friendList = new Vector(); //��Ŵ򿪵�����Ĵ���
	private Hashtable ht_friend = new Hashtable(); //��ȡ�򿪵ĶԻ���	
	private boolean doubleClick = false;
	private boolean login = true;
	private String rightNow;
	private InetAddress clientAddress;
	private Socket connection;
	private DataInputStream in;
	private DataOutputStream out;
	private String strIP;
	private int port = 3000;
	private recThread rec;
	
	private JPanel panel;
	private JScrollPane scrollPane; //������ʾ�����б�
	private JButton button;   //�ҵĺ���
	private JButton btnFind;   //���Ұ�ť

	/**
	 * Create the frame
	 * @throws SQLException 
	 */
	//�رհ�ť�����¼�
	private class WindowCloser extends WindowAdapter
	{
		public void windowClosing(WindowEvent we)
		{
			Client.this.clientClosed();
		}
	}
	private void clientClosed()
	{
		try {
			out.writeUTF("Q");
		} catch (IOException e) {
		}
		finally
		{
			User.setOnLine(0, userNum);
			System.exit(0);
		}
	}
	
	//������ʾ����Ի���
	private void showChat(int friendNum)
	{
		//int lastIndex = 0;
		//System.out.println(friendNum);
		Enumeration en = friendList.elements();
		while(en.hasMoreElements())
		{
			String temp = (String)en.nextElement();
			//lastIndex++;
			if(temp.equals(""+friendNum))
			{
				return;
			}
		}
		friendList.add(friendNum+"");
		
		Chat c = new Chat(Client.this.userNum,friendNum,Client.this);
		c.setVisible(true);
		ht_friend.put(friendNum+"", c);
	}

	
	//����Ϊ�󶨺�����Ϣ

	private void setFriendList(JPanel panel) throws SQLException
	{
		int top = 5;
		int left = 5;
		int width = 190;
		int height = 60;
		int increment = 60;
		int size = 0;
		String logoStr = null;
		String nameStr = null;
		String info = null;
		
		//���Լ��ĸ�����Ϣ
		ResultSet rs = sh.getQuery("select userLogo,userName,userInformation from tbl_Users where userNum="+ userNum);
		if(rs.next())
		{
			logoStr = "/image/"+rs.getInt(1)+".jpg";
			nameStr = rs.getString(2);
			info = rs.getString(3);
		}
		ImageIcon logo = new ImageIcon(this.getClass().getResource(logoStr));
		final JButton btnLogo = new JButton(logo);
		btnLogo.setBounds(5, 5, 50, 50);
		getContentPane().add(btnLogo);
		
		
		final JLabel lblMy = new JLabel(userNum+" ����");
		lblMy.setBounds(70, 8, 100, 20);
		getContentPane().add(lblMy);
		final JLabel lblInfo = new JLabel(nameStr);
		lblInfo.setBounds(70, 20, 100, 40);
		getContentPane().add(lblInfo);
		
		//Ϊ������Ϣ�����ݰ�
	    rs = sh.getQuery("select friendNum from tbl_Friends where userNum="+ userNum);
	   
	    while(rs.next())
	    {
	    	int friendNum = rs.getInt(1);
	    	User ufriend = User.getUser("select * from tbl_Users where userNum="+ friendNum);
	    	friend.add(ufriend);
	    }
	    Collections.sort(friend,new User());
	    Enumeration en = friend.elements();
	    while(en.hasMoreElements())
	    {
	    	User fUser = (User)en.nextElement();
	    	//System.out.println(fUser.isOnLine);
	    	if(fUser.isOnLine==1)
	    	{
	    		logoStr = "/image/"+fUser.userLogo+".jpg";
	    	}
	    	else
	    	{
	    		logoStr = "/image/copy/"+fUser.userLogo+".jpg";
	    	}
	    	nameStr = fUser.userName;
	    	info = fUser.userInformation;
	    	friendNum = fUser.userNum;
	 
	    	
	    	final JButton bf = new JButton();
			JLabel lblfName = new JLabel();
			JLabel lblfInfo = new JLabel();
			final JPanel pnlFriend = new JPanel();
			pnlFriend.addMouseListener(new MouseAdapter(){
				//��������¼�
				public void mouseEntered(MouseEvent e) {
					// TODO �Զ����ɷ������
					pnlFriend.setBackground(new Color(221,232,243));
				}
				//����Ƴ����¼�
				public void mouseExited(MouseEvent e) {
					// TODO �Զ����ɷ������
					pnlFriend.setBackground(Color.WHITE);
				}
			});
			pnlFriend.setLayout(null);
			pnlFriend.setBackground(Color.WHITE);
			bf.setBounds(5, 10, 50, 50);
			lblfName.setBounds(60, 10, 100, 20);
			lblfInfo.setBounds(60, 30, 150, 20);
			pnlFriend.add(bf);
			pnlFriend.add(lblfName);
			pnlFriend.add(lblfInfo);
			
	    	logo = new ImageIcon(this.getClass().getResource(logoStr));
	    	bf.setIcon(logo);
	    	bf.setActionCommand(friendNum+"");
	    	bf.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					// TODO �Զ����ɷ������
					if(doubleClick)
					{
						int friendNum = new Integer(e.getActionCommand()).intValue();
						Client.this.showChat(friendNum);//������ʾ����Ի���
					}
					doubleClick = false;
				}
	    	});
	    	bf.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()>=2)
				{
					doubleClick = true;
				}
			}
	    	});
	    	lblfName.setText(nameStr);
	    	lblfInfo.setText(info);
	    	panel.add(pnlFriend);
	    	pnlFriend.setBounds(left, top, width, height);
	    	top = top + increment;
	    	size = size + increment;
	    }
	    Dimension area = new Dimension(); 
		area.height=size;
		area.width=200;
		panel.setPreferredSize(area);
	}
	
		
	
//	���ڳ�ʼ������Ŀؼ�
	private void setup()
	{
		button = new JButton();
		
		btnFind = new JButton("����");
		btnFind.setIcon(new ImageIcon("image\\find.png"));
		
		button.setText("�ҵĺ���");
		button.setBounds(0, 60, 200, 20);
		getContentPane().add(button);

		
		
		btnFind.setBounds(100, 445, 100, 20);

		this.getContentPane().add(btnFind);
		//final JPanel panel = new JPanel();//������Ϣ�б�
		panel = new JPanel();//������Ϣ�б�
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		try {
			setFriendList(panel);
		} catch (SQLException e) {
			// TODO �Զ����� catch ��
			e.printStackTrace();
		}
	    scrollPane = new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(0, 80, 200, 320);
		getContentPane().add(scrollPane);
		registerEvent();

	}
    
	//ע�ᴰ��Ŀؼ��¼�
	
	private void registerEvent()
	{
		//�ؼ����¼�����
		btnFind.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				FindFriend f = new FindFriend(Client.this,userNum);
				f.setVisible(true);
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!scrollPane.isVisible())
				{
					scrollPane.setBounds(0, 80, 200, 320);
					scrollPane.setVisible(true);
				
				}
			}
		});
		
	}

	//���캯��
	
	public Client(int userNum) {
		super("JIM");
		this.userNum = userNum;
		friend = new Vector();
		sh = new SqlHelper();
		sh.setStatement(sh.getConnection());
		User.setOnLine(1, userNum);
		addWindowListener(new WindowCloser());
		getContentPane().setLayout(null);
		this.getContentPane().setBackground(new Color(221,232,243));
		setBounds(100, 100, 208, 500);
		setup(); //�ؼ���ʼ��
		ready(); //׼���߳�
		rec = new recThread();
		//
	}


	
	//�رնԻ��򴥷����¼�
	public void closeChat(String key)
	{
		ht_friend.remove(key);
		friendList.remove(key);
	}
	
	//Ϊ���ӷ�������׼��
	
	
	public void ready()
	{
		try {
			clientAddress = InetAddress.getLocalHost();
			byte[] ip = clientAddress.getAddress();
		    strIP = (ip[0]&0xFF)+"."+(ip[1]&0xFF)+
					"."+(ip[2]&0xFF)+"."+(ip[3]&0xFF);
		    User.setIP(strIP, this.userNum);
			connection = new Socket(strIP,port);
			in = new DataInputStream(connection.getInputStream());
			out = new DataOutputStream(connection.getOutputStream());
			out.writeUTF("L "+userNum+"");
		} catch (UnknownHostException e) {
			// TODO �Զ����� catch ��
			JOptionPane.showMessageDialog(Client.this, "δ�ҵ�������!");
			Client.this.clientClosed();
		} catch (IOException e) {
			// TODO �Զ����� catch ��
			JOptionPane.showMessageDialog(Client.this, "δ�ҵ�������!");
			Client.this.clientClosed();
		}
	}

	//	 ���ڽ��շ�������Ϣ���߳���
	
	public void sendMessage(String string)
	{
		try {
			out.writeUTF(string);
		} catch (IOException e) {
			// TODO �Զ����� catch ��
			JOptionPane.showMessageDialog(Client.this, "δ�ҵ�������!");
			Client.this.clientClosed();
		}
	}
	
	//���ڸ��´���
	
	public void updateClient()
	{
		try {
			friend.removeAllElements();
			panel.removeAll();
			Client.this.setFriendList(panel);
		}catch (SQLException e) {
			// TODO �Զ����� catch ��
			e.printStackTrace();
		} 
		panel.updateUI();
	}
	
	//���ڽ��ܷ���������Ϣ
	
	private class recThread extends Thread
	{
		public recThread()
		{
			start();
		}
		public void run()
		{
			try{
				while(login){
					String line = in.readUTF();
					rightNow = Calendar.getInstance().getTime().toString();
					if(line.charAt(0) == 'Q'){
						if(line.length() == 1){
							// �˳�
							connection.close();
							login = false;
							break;
						}
						else{
							
							updateClient();
						}
					}
					else if(line.charAt(0) == 'L'){
						
						updateClient();
						
					}
					
					else if(line.charAt(0) == 'A'){
						
					}
					else if(line.charAt(0)== 'S')//���ܵ�ϵͳ��Ϣ
					{
						Enumeration en = ht_friend.elements();
						line = " " + line.substring(1,line.indexOf(" ")) + "  "+ rightNow + "\n   "+ line.substring(line.indexOf(" "));
						while(en.hasMoreElements())
						{
							Chat s = (Chat)en.nextElement();
							s.setMessage(line);
						}
					}
					else{
						//System.out.println(line.substring(0,line.indexOf(" ")));
						//System.out.println(line);
						String sendUser = line.substring(1,line.indexOf(" "));
						String sendUserName = User.getName(new Integer(sendUser).intValue());
						char top = line.charAt(0);


						boolean open = true;
						//�û����ܺ��ѷ�������Ϣ
						Chat temp = null;
						try
						{
						    temp = (Chat)ht_friend.get(sendUser);
						}
						catch(Exception e)
						{
							open =false;
						}
						if(temp==null)
						{
							open =false;
						}
						if(open == false)
						{
							temp = new Chat(Client.this.userNum,new Integer(sendUser).intValue(),Client.this);
							temp.setVisible(true);
							ht_friend.put(sendUser, temp);
							friendList.add(sendUser);
						}
						if(top=='M')
						{
							//��ʽ���������
							line = " " + sendUserName + "  "+ rightNow + "\n   "+ line.substring(line.indexOf(" "));
							temp.setVisible(true);
							temp.setMessage(line);
						}
						
					}
				}
			}catch(SocketException se){
				rightNow = Calendar.getInstance().getTime().toString();
				login = false;		
			}catch (IOException ioe){
				
			}
		}
	}

}
