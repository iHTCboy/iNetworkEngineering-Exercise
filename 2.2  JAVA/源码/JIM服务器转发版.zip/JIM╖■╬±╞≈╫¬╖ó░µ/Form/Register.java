package Form;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.FocusManager;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import DataLayer.SqlHelper;
//ע���࣬������д���ʹ��幹���д����������
public class Register extends JFrame{
	
	private JTextField cboxuserName;
	private JTextField cboxpassword;
	private JTextField cboxuserNick;
	private JTextField cboxuserInfo;
	private JTextField cboxuserLogo;
	private JTextField cboxuserSex;
	private JTextField cboxuserEmail;
	private JButton buttonRegister;
	SqlHelper sh ;
	JPanel panel;
	
	
	
	public void setup()
	{
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(5, 55, 310, 420);
		getContentPane().add(panel);
		panel.setBackground(new Color(241,250,255));
		final JLabel lbluserName = new JLabel("�û��ʺ�");
		lbluserName.setBounds(30, 40, 60, 15);
		final JLabel lblpassword = new JLabel("�û�����");
		lblpassword.setBounds(30, 90, 60, 15);
		final JLabel lbluserNick = new JLabel("�û��ǳ�");
		lbluserNick.setBounds(30, 140, 60, 15);
		final JLabel lbluserInfo = new JLabel("�û���Ϣ");
		lbluserInfo.setBounds(30, 190, 60, 15);
		final JLabel lbluserLogo = new JLabel("ͷ����");
		lbluserLogo.setBounds(30, 240, 60, 15);
		final JLabel lbluserSex = new JLabel("�û��Ա�");
		lbluserSex.setBounds(30, 290, 60, 15);
		final JLabel lbluserEmail = new JLabel("�����ʼ�");
		lbluserEmail.setBounds(30, 340, 60, 15);
		
		
		
		panel.add(lbluserName);
		panel.add(lblpassword);
		panel.add(lbluserNick);
		panel.add(lbluserInfo);
		panel.add(lbluserLogo);
		panel.add(lbluserSex);
		panel.add(lbluserEmail);
		
		
		
		
		cboxuserName = new JTextField();
		cboxuserName.setBounds(90, 38, 120, 20);
		cboxuserName.setEditable(true);
		panel.add(cboxuserName);
			

		cboxpassword = new JTextField();
		cboxpassword.setBounds(90, 88, 120, 21);
		cboxpassword.setEditable(true);
	    panel.add(cboxpassword);
	    
	    cboxuserNick = new JTextField();
		cboxuserNick.setBounds(90, 138, 120, 20);
		cboxuserNick.setEditable(true);
		panel.add(cboxuserNick);
		
		
		
		cboxuserInfo = new JTextField();
		cboxuserInfo.setBounds(90, 188, 120, 20);
		cboxuserInfo.setEditable(true);
		panel.add(cboxuserInfo);
		
		cboxuserLogo = new JTextField();
		cboxuserLogo.setBounds(90, 238, 120, 20);
		cboxuserLogo.setEditable(true);
		panel.add(cboxuserLogo);
		
		cboxuserSex = new JTextField();
		cboxuserSex.setBounds(90, 288, 120, 20);
		cboxuserSex.setEditable(true);
		panel.add(cboxuserSex);
		
		cboxuserEmail = new JTextField();
		cboxuserEmail.setBounds(90, 338, 120, 20);
		cboxuserEmail.setEditable(true);
		panel.add(cboxuserEmail);
	    
		buttonRegister = new JButton();
	    buttonRegister.setText("ע��");
	    buttonRegister.setBounds(200, 375, 80, 23);
	    panel.add(buttonRegister);
	    register();
	
	
	}
	
	
	public void register()
	{
		//�˺������س��������¼�
		cboxuserName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FocusManager.getCurrentManager().focusNextComponent();
			}
		});
		
		//�����س��������¼�
		cboxpassword.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		buttonRegister.doClick();
	    	}
	    });
	    		
		buttonRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName =((String) cboxuserName.getText());
				String password =((String) cboxpassword.getText());
				String nickname =((String) cboxuserNick.getText());
				String info=((String) cboxuserInfo.getText());
				String logo=((String) cboxuserLogo.getText());
				String sex=((String) cboxuserSex.getText());
				String email=((String) cboxuserEmail.getText());
				if(userName==null||password==null||userName.equals("")||password.equals("")||nickname==null||nickname.equals(""))
				{
					JOptionPane.showMessageDialog(Register.this, "�벹��������Ϣ!");
					return;
				}
				userName = userName.trim().replace("'", "");
				password = password.trim().replace("'", "");
				nickname = nickname.trim().replace("'", "");
				info = info.trim().replace("'", "");
				logo = logo.trim().replace("'", "");
				sex = sex.trim().replace("'", "");
				email = email.trim().replace("'", "");
				int userNum = 0;
				int Logo=0;
				try
				{
					userNum = new Integer(userName).intValue();
					Logo= new Integer(logo).intValue();
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(Register.this, "�û�������ȷ");
					return;
				}
				sh = new SqlHelper();
				sh.setStatement(sh.getConnection());
				ResultSet rs = sh.getQuery("select userNum from tbl_Users where userNum="+userNum);
				try {
					if(rs.next())
					{
						if(rs.getInt(1)==userNum)
						{
							JOptionPane.showMessageDialog(Register.this, "���û��Ѿ���ע��");
							return;
						}	
						
					}
				} catch (SQLException e1) {
					// TODO �Զ����� catch ��
					e1.printStackTrace();
				}
				sh.getUpdate("SET IDENTITY_INSERT [tbl_Users] ON insert tbl_Users (userNum , userName , password  , userInformation , userLogo , sex , email ) values ( "+userNum+" , '"+nickname+"' , '"+password+"'  , '"+info+"' , "+Logo+" , '"+sex+"' , '"+email+"' )");
				sh.closeStatement();
				JOptionPane.showMessageDialog(Register.this, "�û�ע��ɹ�!");
			    Register.this.dispose();
			}
		});
	}
	public Register()
	{
		super("JIMע�ᴰ��");
		getContentPane().setLayout(null);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = 330;
		int height = 500;
		this.setBounds((d.width - width) / 2, (d.height - height) / 2, width, height);
		this.setResizable(false);
		ImageIcon logo = new ImageIcon(this.getClass().getResource("/image/top.jpg"));
		final JLabel login = new JLabel(logo);
		login.setBounds(0, 0, 330, 55);
		getContentPane().add(login);
		getContentPane().setBackground(new Color(225,245,252));
		setup();
		
		
		
	}
	

}
