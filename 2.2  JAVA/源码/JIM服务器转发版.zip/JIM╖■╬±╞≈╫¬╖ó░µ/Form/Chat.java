package Form;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Calendar;
import business.*;
import javax.swing.*;

public class Chat extends ChatBase implements ActionListener{

	/**
	 * Launch the application
	 * @param args
	 */
	// ��Ӧ�رհ�ť���ڲ���
	private JMenuBar br = new JMenuBar();
	private class WindowCloser extends WindowAdapter 
	{
		public void windowClosing(WindowEvent we)
		{
			parent.closeChat(friendNum+"");
			Chat.this.dispose();
		}
	}
	
	
	public Chat(int userNum,int friendNum,Client parent) {
		super();
		this.userNum = userNum;
		this.friendNum = friendNum;
		this.userName = User.getName(userNum);
		this.parent = parent;
		String friendName = User.getName(friendNum);
		this.setTitle("��������"+friendName+"�Ի�");
		setBounds(100, 100, 600, 375);
		setResizable(false);
		addWindowListener(new WindowCloser());
		setup();
		this.setJMenuBar(br);
	}
	
	public void setMessage(String string) {
		// TODO �Զ����ɷ������
		input.append(string+"\n");
		input.setCaretPosition(input.getText().length());//�L�ӵ��׶�

	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO �Զ����ɷ������
		if(e.getActionCommand().equals("����"))
		{
			parent.sendMessage("M"+friendNum+" "+output.getText());
			String rightNow = Calendar.getInstance().getTime().toString();
			input.append(" "+userName+"   "+rightNow+"\n   "+output.getText()+"\n");
			output.setText("");
		}
		else if(e.getActionCommand().equals("ȡ��"))
		{
			parent.closeChat(friendNum+"");
			Chat.this.dispose();
		}
		else
		{
			setResizable(true);
			java.awt.Rectangle rv = Chat.this.getBounds();
			int width = rv.width;
			if(openRecrod)
			{
				width += 200;
				openRecrod=false;
				panel.setVisible(true);
			}
			else
			{
				panel.setVisible(false);
				width -=200;
				openRecrod=true;
			}
			Chat.this.setBounds(rv.x, rv.y, width, rv.height);
			setResizable(false);
		}
	}
}
