package Form;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import DataLayer.SqlHelper;
import business.*;

public class FindFriend extends JFrame {

	/**
	 * Launch the application
	 * @param args
	 */
	private DefaultTableModel defaultModel;
	private JTable table;
	private ResultSet rs;
	private JScrollPane scrollPane;
	private SqlHelper sh = new SqlHelper();
	private JPopupMenu pm = new JPopupMenu();
	private JMenuItem addition;
	private JMenuItem delete;
	private int userList;
	private int friendNum;
	private int userNum;
	private Client parent;
	
	//Ϊ���嶨���¼�
	public void register()
	{
	    table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				// TODO �Զ����ɷ������
				int mods=e.getModifiers(); 
				if((mods&InputEvent.BUTTON3_MASK)!=0) 
				{ 
					pm.show(table, e.getX(),e.getY());
					if(table.getSelectedRow()>=0)
					friendNum = new Integer((String) table.getValueAt(table.getSelectedRow(), 0)).intValue();
				}
			}
	    	
	    });
	    
	    addition.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(userNum==friendNum)
				{
					JOptionPane.showMessageDialog(FindFriend.this, "���������Լ�!");
					return;
				}
				Friend f = new Friend(userNum,friendNum);
				if(f.addFriend()==0)
				{
					JOptionPane.showMessageDialog(FindFriend.this, "���û��Ѿ��Ǻ���!");
				}
				else
				{
					JOptionPane.showMessageDialog(FindFriend.this, "����ɹ�!");
					parent.updateClient();
				}
			}
	    	
	    });
	    
	    delete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(userNum==friendNum)
				{
					JOptionPane.showMessageDialog(FindFriend.this, "����ɾ���Լ�!");
					return;
				}
				Friend f = new Friend(userNum,friendNum);
				if(f.deleteFriend()==0)
				{
					JOptionPane.showMessageDialog(FindFriend.this, "ɾ�����ѳɹ�!");
					parent.updateClient();
				}
				else
				{
					JOptionPane.showMessageDialog(FindFriend.this, "���û�������ĺ���!");
					
				}
			}
	    	
	    });
	}
	
	//Ϊ���������ݰ�
	public void bind(String sql)
	{
		String Head[] = {"�û��˺�","�û���","�Ա�","�Ƿ�����"}; 
		Object info[][] = {};
		try{		
			rs =  sh.getQuery(sql);
			defaultModel = new DefaultTableModel(info,Head);
		    table.setModel(defaultModel);//�Ը�ģ��Ϊ��������
		    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);//�������óɲ��Զ������еĿ��ȣ�ʹ�ù�������      	
		    TableColumn column;
		    table.add(pm);
			column=table.getColumnModel().getColumn(0);
			column.setPreferredWidth(100);
		    column=table.getColumnModel().getColumn(1);
			column.setPreferredWidth(100);
			column=table.getColumnModel().getColumn(2);
			column.setPreferredWidth(100);
			column=table.getColumnModel().getColumn(3);
			column.setPreferredWidth(100);
			while(rs.next()){
				String userNum = rs.getString(1);
				String userName = rs.getString(2);
				String sex = rs.getString(3);
				String online = "������";
				if(rs.getInt(4)==1)
				{
					online = "����";
				}
				defaultModel.addRow(new Vector());
				defaultModel.setValueAt(userNum, defaultModel.getRowCount() - 1, 0);//��д��¼
			    defaultModel.setValueAt(userName, defaultModel.getRowCount() - 1, 1);
			    defaultModel.setValueAt(sex, defaultModel.getRowCount() - 1, 2);
			    defaultModel.setValueAt(online, defaultModel.getRowCount() - 1, 3);
			}
		}catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	//Ϊ�����ʼ��
	public void setup()
	{
		addition =new JMenuItem("��Ϊ����");
		delete=new JMenuItem("ɾ������");
		pm.add(addition);
		pm.add(delete);
		scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
		table = new JTable(3,5);
		scrollPane.setViewportView(table);
		String sql = "SELECT userNum,userName,sex,isOnLine FROM tbl_Users order by isOnLine desc";
		bind(sql);
		this.getContentPane().add(scrollPane);
		register();
	}
	
	public FindFriend(Client parent ,int userNum) {
		super("�����û�����");
		this.userNum = userNum;
		this.parent = parent;
		setBounds(100, 100, 411, 200);
		sh.setStatement(sh.getConnection());
		setup();
		this.setResizable(false);
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});
		//
	}

}
