package test;

public class Counter {
	private int count=1;
	public int getCount(){
		return count++;
	}
}
