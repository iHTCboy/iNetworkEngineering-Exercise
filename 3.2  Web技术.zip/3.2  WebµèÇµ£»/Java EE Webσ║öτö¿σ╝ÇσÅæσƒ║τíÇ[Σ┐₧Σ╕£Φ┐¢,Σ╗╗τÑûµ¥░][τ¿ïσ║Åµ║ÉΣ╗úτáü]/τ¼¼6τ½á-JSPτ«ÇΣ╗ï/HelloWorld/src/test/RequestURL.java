package test;

public class RequestURL {
	private String url="home.jsp";
	public String getURL(){
		return url;
	}
	public void setURL(String aURL){
		url=aURL;
	}
}
