import com.opensymphony.xwork2.ActionSupport;
public class ItemsAction extends ActionSupport {
public String execute() throws Exception {
return SUCCESS;
}
public String add() throws Exception {
return SUCCESS;
}
public String edit() throws Exception {
return SUCCESS;
}
}
