import com.opensymphony.xwork2.Action;
public class LoginAction2 implements Action {
public String execute() {
			//return "success";
			return this.SUCCESS; //SUCCESS����ֵΪ��"success"
		}
}
