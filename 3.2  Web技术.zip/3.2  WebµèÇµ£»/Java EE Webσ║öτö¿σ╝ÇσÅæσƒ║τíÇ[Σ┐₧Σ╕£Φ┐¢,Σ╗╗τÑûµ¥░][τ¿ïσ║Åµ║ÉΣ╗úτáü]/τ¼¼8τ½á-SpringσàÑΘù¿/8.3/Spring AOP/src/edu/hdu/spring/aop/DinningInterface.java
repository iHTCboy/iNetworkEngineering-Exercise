package edu.hdu.spring.aop;
public interface DinningInterface {
public void eat();
}

/*DinningInterfaceImpl.java �ӿ�ʵ����*/
