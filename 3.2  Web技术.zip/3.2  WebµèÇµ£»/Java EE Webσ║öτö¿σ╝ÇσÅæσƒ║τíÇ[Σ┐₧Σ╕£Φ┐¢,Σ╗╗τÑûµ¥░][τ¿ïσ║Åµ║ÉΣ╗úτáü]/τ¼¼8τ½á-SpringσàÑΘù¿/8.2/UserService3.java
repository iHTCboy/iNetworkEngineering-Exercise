public class UserService { 
private UserDAO userDao;
public UserService (UserDAO dao) { 
this.userDao = dao; 
} 
���� 
}
