public class UserService { 
private UserDAO userDao; 
public void setUserDao(UserDAO dao) { 
this.userDao = dao; 
} 
����
}
