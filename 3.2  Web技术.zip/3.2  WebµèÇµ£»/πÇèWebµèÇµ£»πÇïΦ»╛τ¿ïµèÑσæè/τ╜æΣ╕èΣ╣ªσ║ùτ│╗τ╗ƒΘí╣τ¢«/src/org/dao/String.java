package org.dao;

public class String {

}
