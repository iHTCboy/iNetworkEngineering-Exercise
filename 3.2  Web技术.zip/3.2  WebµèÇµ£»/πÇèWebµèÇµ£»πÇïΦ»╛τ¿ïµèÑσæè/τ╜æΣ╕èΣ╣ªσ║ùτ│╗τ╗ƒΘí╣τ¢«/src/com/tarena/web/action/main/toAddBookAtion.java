package com.tarena.web.action.main;

public class toAddBookAtion {
	public String execute(){
		
		return "toAddBookAtion";
	}
}
