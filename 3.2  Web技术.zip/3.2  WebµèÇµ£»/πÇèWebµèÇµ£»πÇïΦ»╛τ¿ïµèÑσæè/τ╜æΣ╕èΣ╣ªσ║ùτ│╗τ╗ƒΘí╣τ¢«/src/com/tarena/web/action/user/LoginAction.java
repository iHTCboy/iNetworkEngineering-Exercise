package com.tarena.web.action.user;

public class LoginAction {
	public String execute(){
		
		return "login_form";
	}
}
