package com.tarena.web.action.user;

public class ToAdminMainAction {
	public String execute(){
		
		return "toadminMain";
	}
}
