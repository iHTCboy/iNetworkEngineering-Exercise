package com.tarena.web.action.main;

public class LoginAction {
	public String execute(){
		
		return "login_form";
	}
}
