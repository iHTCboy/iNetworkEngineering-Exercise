package com.tarena.web.action.user;


public class DoRegistAction{
	/**
	 * 跳转到注册页面
	 * 
	 * @return
	 */
	public String execute() {
		return "register_form";
	}
}
