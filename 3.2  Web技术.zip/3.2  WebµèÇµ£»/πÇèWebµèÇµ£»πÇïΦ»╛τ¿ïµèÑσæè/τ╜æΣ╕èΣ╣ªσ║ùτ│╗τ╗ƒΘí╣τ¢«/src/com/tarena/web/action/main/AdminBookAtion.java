package com.tarena.web.action.main;

public class AdminBookAtion {
	public String execute(){
		
		return "adminBookList";
	}
}
