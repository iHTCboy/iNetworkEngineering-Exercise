package com.tarena.web.action.user;


public class LoginAdminAction{

	public String execute() {
		return "adminLogin";
	}
}
