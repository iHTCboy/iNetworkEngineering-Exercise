package com.tarena.entity;

public class Admins {
	

	private Integer AdminID;
	private String LoginName;
	private String password;
	
	public Integer getAdminID() {
		return AdminID;
	}
	public void setAdminID(Integer adminID) {
		AdminID = adminID;
	}
	public String getLoginName() {
		return LoginName;
	}
	public void setLoginName(String loginName) {
		LoginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		password = password;
	}
	
}
